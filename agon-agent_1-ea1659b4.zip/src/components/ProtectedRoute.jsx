import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-royal">
      <div className="text-gold font-italiana tracking-[0.3em] text-xl animate-pulse">CHARLOTTE</div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return children;
}
