import { useState, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MessageCircle, X, Minus, Send } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import supabase from '../lib/supabase';

function getSessionId() {
  let id = localStorage.getItem('charlotte_chat_session');
  if (!id) {
    id = 'sess_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('charlotte_chat_session', id);
  }
  return id;
}

export default function LiveChat() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [started, setStarted] = useState(false);
  const [visitorName, setVisitorName] = useState('');
  const [visitorEmail, setVisitorEmail] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const sid = getSessionId();
    fetch(`/api/conversations?session_id=${sid}`).then(r => r.json()).then(data => {
      if (Array.isArray(data) && data.length > 0) {
        setConversation(data[0]);
        setStarted(true);
        loadMessages(data[0].id);
        subscribeMessages(data[0].id);
      }
    }).catch(e => console.error('Conv fetch error:', e));
  }, [open]);

  useEffect(() => {
    if (user) {
      setVisitorName(user.user_metadata?.full_name || user.email?.split('@')[0] || '');
      setVisitorEmail(user.email || '');
    }
  }, [user]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  useEffect(() => {
    if (open) setUnreadCount(0);
  }, [open]);

  const loadMessages = async (convId) => {
    try {
      const res = await fetch(`/api/messages?conversation_id=${convId}`);
      const data = await res.json();
      setMessages(data || []);
    } catch (e) { console.error('Messages fetch error:', e); }
  };

  const subscribeMessages = (convId) => {
    const channel = supabase.channel(`chat-${convId}`).on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
      (payload) => {
        setMessages(prev => prev.find(m => m.id === payload.new.id) ? prev : [...prev, payload.new]);
        if (payload.new.sender_type === 'admin' && !open) setUnreadCount(c => c + 1);
      }).subscribe();
    return () => supabase.removeChannel(channel);
  };

  const startConversation = async () => {
    if (!visitorName.trim()) return;
    setSending(true);
    try {
      const body = { session_id: getSessionId(), user_id: user?.id || null, visitor_name: visitorName.trim(), visitor_email: visitorEmail.trim() || null };
      const res = await fetch('/api/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const conv = await res.json();
      setConversation(conv);
      setStarted(true);
      subscribeMessages(conv.id);
      const intro = `Hello, my name is ${visitorName.trim()}. I'd like to inquire about your services.`;
      await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation_id: conv.id, sender_type: 'visitor', sender_name: visitorName.trim(), content: intro }) });
    } catch (e) { console.error('Start conv error:', e); } finally { setSending(false); }
  };

  const sendMessage = async () => {
    if (!input.trim() || !conversation || sending) return;
    setSending(true);
    const msg = input.trim();
    setInput('');
    try {
      await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation_id: conversation.id, sender_type: 'visitor', sender_name: visitorName, content: msg }) });
    } catch (e) { console.error('Send error:', e); } finally { setSending(false); }
  };

  const onKey = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };

  return (
    <>
      <AnimatePresence>
        {!open && (
          <motion.button initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
            onClick={() => { setOpen(true); setMinimized(false); }} className="fixed bottom-6 right-6 z-40 group" aria-label="Open live chat">
            <div className="relative">
              {unreadCount > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#a8424d] text-white text-xs rounded-full flex items-center justify-center font-medium border-2 border-[#0a0908]">{unreadCount}</span>}
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center shadow-2xl shadow-[rgba(201,169,97,0.4)] group-hover:scale-110 transition-transform">
                <MessageCircle size={22} className="text-[#0a0908]" strokeWidth={2.2} />
              </div>
              <div className="absolute inset-0 rounded-full bg-[#c9a961] animate-pulse-gold opacity-50" />
            </div>
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: 30, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25 }} className="fixed bottom-6 right-6 z-50 w-[calc(100vw-3rem)] sm:w-[400px] bg-[#14110f] border-gold-soft border shadow-2xl flex flex-col"
            style={{ height: minimized ? '64px' : '560px', maxHeight: '85vh' }}>
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-gold-soft bg-gradient-to-r from-[rgba(45,90,63,0.2)] to-[rgba(107,68,35,0.15)]">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center text-[#0a0908] font-italiana text-sm">CP</div>
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#5a8a4f] rounded-full border-2 border-[#14110f]" />
                </div>
                <div>
                  <div className="text-cream text-sm font-medium tracking-wide">Charlotte Prestige</div>
                  <div className="text-[0.65rem] text-gold tracking-[0.2em] uppercase">Online · Discreet</div>
                </div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => setMinimized(!minimized)} className="p-2 text-cream-dim hover:text-gold transition-colors" aria-label="Minimize"><Minus size={16} /></button>
                <button onClick={() => setOpen(false)} className="p-2 text-cream-dim hover:text-cream transition-colors" aria-label="Close"><X size={16} /></button>
              </div>
            </div>

            {!minimized && (
              <>
                {/* Messages or Intro */}
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-3 bg-[rgba(10,9,8,0.4)]">
                  {started ? (
                    <>
                      {messages.length === 0 && (
                        <div className="text-center py-8 text-cream-dim text-sm">
                          <div className="ornament-line mb-3 justify-center"><span>Awaiting Reply</span></div>
                          Your message has been received. A concierge will respond shortly.
                        </div>
                      )}
                      {messages.map((msg) => (
                        <motion.div key={msg.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                          className={`flex ${msg.sender_type === 'visitor' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[78%] px-4 py-2.5 text-sm leading-relaxed ${msg.sender_type === 'visitor' ? 'bg-gradient-to-br from-[rgba(201,169,97,0.9)] to-[rgba(168,136,74,0.9)] text-[#0a0908] rounded-l-lg rounded-tr-lg' : 'bg-[rgba(34,29,24,0.95)] text-cream border-gold-soft border rounded-r-lg rounded-tl-lg'}`}>
                            {msg.content}
                          </div>
                        </motion.div>
                      ))}
                    </>
                  ) : (
                    <div className="space-y-4">
                      <div className="text-center py-4">
                        <div className="ornament-line mb-3 justify-center"><span>Welcome</span></div>
                        <h3 className="font-display text-2xl text-cream mb-2">A Private Word</h3>
                        <p className="text-sm text-cream-dim font-light leading-relaxed">Introduce yourself, and a member of our concierge team will be with you shortly.</p>
                      </div>
                      <div>
                        <label className="label-royal">Your Name</label>
                        <input type="text" value={visitorName} onChange={e => setVisitorName(e.target.value)} placeholder="How shall we address you?" className="input-royal" />
                      </div>
                      <div>
                        <label className="label-royal">Email <span className="text-cream-dim">(optional)</span></label>
                        <input type="email" value={visitorEmail} onChange={e => setVisitorEmail(e.target.value)} placeholder="For our reply" className="input-royal" />
                      </div>
                      <button onClick={startConversation} disabled={!visitorName.trim() || sending} className="btn-primary w-full text-xs">{sending ? 'Connecting…' : 'Begin Conversation'}</button>
                    </div>
                  )}
                </div>

                {/* Input */}
                {started && (
                  <div className="p-4 border-t border-gold-soft bg-[#14110f]">
                    <div className="flex items-end gap-2">
                      <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKey} rows={1}
                        placeholder="Type your message…" className="input-royal resize-none min-h-[44px] max-h-24 py-3" />
                      <button onClick={sendMessage} disabled={!input.trim() || sending} className="btn-primary px-4 py-3 flex-shrink-0" aria-label="Send">
                        <Send size={16} />
                      </button>
                    </div>
                    <div className="text-[0.6rem] text-cream-dim text-center mt-2 tracking-[0.2em] uppercase">Encrypted · Discreet · 24/7</div>
                  </div>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
