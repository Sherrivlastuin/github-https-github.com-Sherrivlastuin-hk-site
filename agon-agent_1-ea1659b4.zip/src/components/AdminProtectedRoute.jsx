import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function AdminProtectedRoute({ children }) {
  const { user, isAdmin, loading } = useAuth();
  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-royal">
      <div className="text-gold font-italiana tracking-[0.3em] text-xl animate-pulse">CHARLOTTE</div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  if (!isAdmin) return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center bg-royal">
      <div className="text-gold font-italiana tracking-[0.3em] text-2xl mb-6">RESTRICTED ACCESS</div>
      <h1 className="font-display text-4xl text-cream mb-4">The Prestige Chambers are Locked</h1>
      <p className="text-cream-dim max-w-md">This area is reserved for authorized personnel. Please sign in with the appropriate credentials.</p>
    </div>
  );
  return children;
}
