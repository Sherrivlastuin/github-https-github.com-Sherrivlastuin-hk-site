import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Crown, User, Shield, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/booking', label: 'Book' },
  { to: '/support', label: 'Support' },
  { to: '/contact', label: 'Contact' },
];

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [userMenu, setUserMenu] = useState(false);
  const { user, isAdmin, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setUserMenu(false);
  }, [location.pathname]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled || mobileOpen ? 'bg-[rgba(10,9,8,0.95)] backdrop-blur-md border-gold-soft border-b' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative">
              <svg width="38" height="38" viewBox="0 0 60 60" fill="none" className="transition-transform group-hover:scale-105">
                <path d="M30 4 L36 18 L52 18 L40 28 L44 44 L30 36 L16 44 L20 28 L8 18 L24 18 Z" stroke="#c9a961" strokeWidth="1.2" fill="none" />
                <circle cx="30" cy="28" r="3" fill="#c9a961" />
              </svg>
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-italiana text-xl tracking-[0.2em] text-cream">CHARLOTTE</span>
              <span className="text-[0.55rem] tracking-[0.35em] text-gold mt-1 uppercase">Prestige Management</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <NavLink key={link.to} to={link.to} end={link.to === '/'}
                className={({ isActive }) => `text-sm tracking-[0.15em] uppercase transition-all duration-300 relative py-2 ${isActive ? 'text-gold' : 'text-cream-dim hover:text-cream'}`}>
                {({ isActive }) => (
                  <>
                    {link.label}
                    {isActive && (
                      <motion.span layoutId="navunderline" className="absolute -bottom-1 left-0 right-0 h-px bg-gold" transition={{ type: 'spring', stiffness: 300, damping: 30 }} />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-4">
            {user ? (
              <div className="relative">
                <button onClick={() => setUserMenu(!userMenu)} className="flex items-center gap-2 px-3 py-2 border-gold-soft border hover:border-gold transition-colors">
                  <User size={14} className="text-gold" />
                  <span className="text-sm text-cream tracking-wide">{user.email.split('@')[0]}</span>
                </button>
                <AnimatePresence>
                  {userMenu && (
                    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                      className="absolute right-0 top-full mt-2 w-56 bg-[rgba(20,17,15,0.98)] border-gold-soft border backdrop-blur-md">
                      <Link to="/profile" className="flex items-center gap-3 px-4 py-3 text-sm text-cream hover:bg-[rgba(201,169,97,0.08)] transition-colors">
                        <User size={14} className="text-gold" /> My Profile
                      </Link>
                      {isAdmin && (
                        <Link to="/admin" className="flex items-center gap-3 px-4 py-3 text-sm text-cream hover:bg-[rgba(201,169,97,0.08)] transition-colors border-t border-gold-soft">
                          <Shield size={14} className="text-gold" /> Admin Dashboard
                        </Link>
                      )}
                      <button onClick={handleSignOut} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-cream-dim hover:text-cream hover:bg-[rgba(201,169,97,0.08)] transition-colors border-t border-gold-soft">
                        <LogOut size={14} /> Sign Out
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Link to="/login" className="text-sm tracking-[0.15em] uppercase text-cream-dim hover:text-gold transition-colors">Sign In</Link>
            )}
            <Link to="/booking" className="btn-primary text-xs py-2.5 px-5">Reserve</Link>
          </div>

          {/* Mobile Toggle */}
          <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden p-2 text-cream" aria-label="Toggle menu">
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.nav initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="lg:hidden overflow-hidden">
              <div className="py-4 flex flex-col gap-1">
                {NAV_LINKS.map((link) => (
                  <NavLink key={link.to} to={link.to} end={link.to === '/'}
                    className={({ isActive }) => `px-4 py-3 text-sm tracking-[0.15em] uppercase transition-colors ${isActive ? 'text-gold border-l-2 border-gold bg-[rgba(201,169,97,0.06)]' : 'text-cream-dim hover:text-cream hover:bg-[rgba(201,169,97,0.04)]'}`}>
                    {link.label}
                  </NavLink>
                ))}
                <div className="border-t border-gold-soft mt-3 pt-3 flex flex-col gap-2">
                  {user ? (
                    <>
                      <Link to="/profile" className="px-4 py-3 text-sm text-cream tracking-wide">My Profile</Link>
                      {isAdmin && <Link to="/admin" className="px-4 py-3 text-sm text-cream tracking-wide">Admin Dashboard</Link>}
                      <button onClick={handleSignOut} className="text-left px-4 py-3 text-sm text-cream-dim">Sign Out</button>
                    </>
                  ) : (
                    <Link to="/login" className="px-4 py-3 text-sm text-cream tracking-[0.15em] uppercase">Sign In</Link>
                  )}
                  <Link to="/booking" className="mx-4 btn-primary text-xs mt-2">Reserve Now</Link>
                </div>
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
