import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Instagram, Twitter, Send } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-[#080706] border-t border-gold-soft mt-auto">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[rgba(201,169,97,0.4)] to-transparent" />
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <svg width="34" height="34" viewBox="0 0 60 60" fill="none">
                <path d="M30 4 L36 18 L52 18 L40 28 L44 44 L30 36 L16 44 L20 28 L8 18 L24 18 Z" stroke="#c9a961" strokeWidth="1.2" fill="none" />
                <circle cx="30" cy="28" r="3" fill="#c9a961" />
              </svg>
              <div className="flex flex-col leading-none">
                <span className="font-italiana text-lg tracking-[0.2em] text-cream">CHARLOTTE</span>
                <span className="text-[0.5rem] tracking-[0.35em] text-gold mt-1 uppercase">Prestige Management</span>
              </div>
            </div>
            <p className="text-sm text-cream-dim leading-relaxed font-light">An intimate concierge for the discerning. Discretion, refinement, and an unwavering commitment to the extraordinary.</p>
          </div>

          {/* Navigate */}
          <div>
            <h4 className="text-xs tracking-[0.25em] uppercase text-gold mb-5 font-medium">Navigate</h4>
            <ul className="space-y-3">
              {[['About', '/about'], ['Services', '/services'], ['Reservations', '/booking'], ['Support', '/support'], ['Contact', '/contact']].map(([label, to]) => (
                <li key={to}><Link to={to} className="text-sm text-cream-dim hover:text-gold transition-colors font-light">{label}</Link></li>
              ))}
            </ul>
          </div>

          {/* Experiences */}
          <div>
            <h4 className="text-xs tracking-[0.25em] uppercase text-gold mb-5 font-medium">Experiences</h4>
            <ul className="space-y-3">
              {['Private Companionship', 'Couples Experience', 'Weekend Retreat', 'Travel Companion', 'Private Dining'].map((item) => (
                <li key={item}><Link to="/services" className="text-sm text-cream-dim hover:text-gold transition-colors font-light">{item}</Link></li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="text-xs tracking-[0.25em] uppercase text-gold mb-5 font-medium">Connect</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-sm text-cream-dim font-light">
                <Mail size={14} className="text-gold" />
                <a href="mailto:concierge@charlotteprestige.com" className="hover:text-gold transition-colors">concierge@charlotteprestige.com</a>
              </li>
              <li className="flex items-center gap-3 text-sm text-cream-dim font-light">
                <Phone size={14} className="text-gold" />
                <span>+1 (888) 555-0192</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-cream-dim font-light">
                <MapPin size={14} className="text-gold mt-0.5" />
                <span>By appointment only<br />Manhattan · London · Dubai</span>
              </li>
            </ul>
            <div className="flex gap-3 mt-5">
              {[Instagram, Twitter, Send].map((Icon, i) => (
                <a key={i} href="#" className="p-2 border-gold-soft border hover:border-gold hover:bg-[rgba(201,169,97,0.08)] transition-all">
                  <Icon size={14} className="text-gold" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="divider-gold my-10" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-cream-dim tracking-wider">© {new Date().getFullYear()} Charlotte Prestige Management. All rights reserved.</p>
          <div className="flex gap-6">
            {[['Privacy', '/contact'], ['Terms', '/contact'], ['Discretion', '/contact']].map(([label, to]) => (
              <Link key={label} to={to} className="text-xs text-cream-dim hover:text-gold transition-colors tracking-wider">{label}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
