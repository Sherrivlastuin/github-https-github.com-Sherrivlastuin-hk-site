import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Ticket, MessageCircle, Phone, Send, Check, ChevronDown, BookOpen } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const FAQS = [
  { q: 'How do I make a reservation?', a: 'Navigate to our Reservations page, choose your experience, select a date and time, and provide a few details. Our concierge will confirm your booking personally within hours.' },
  { q: 'What is your cancellation policy?', a: 'Cancellations made more than 48 hours in advance are fully refundable. Within 48 hours, we offer rescheduling at no charge. Companions are vetted and available with proper notice.' },
  { q: 'How is my privacy protected?', a: 'Discretion is our highest principle. Communications are end-to-end encrypted. Personal information is never stored on third-party platforms and is purged after your engagement concludes.' },
  { q: 'What if I need to change my booking?', a: 'Simply open a support ticket or message us via the live chat. Our concierge is available 24/7 to accommodate changes discreetly.' },
  { q: 'Are companions vetted?', a: 'Every companion in our collection is personally interviewed, reference-checked, and trained to the Charlotte Prestige standard of refinement, intelligence, and discretion.' },
  { q: 'Do you offer international services?', a: 'Yes. Our house serves distinguished members across North America, Europe, and the Middle East. Travel companions can be arranged for destination experiences worldwide.' },
];

export default function Support() {
  const { user } = useAuth();
  const [openFaq, setOpenFaq] = useState(-1);
  const [tickets, setTickets] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: user?.user_metadata?.full_name || '', email: user?.email || '', category: 'General', subject: '', message: '', priority: 'normal' });

  useEffect(() => {
    if (user) fetch(`/api/support?user_id=${user.id}`).then(r => r.json()).then(d => setTickets(d || [])).catch(() => {});
  }, [user]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/support', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, user_id: user?.id || null }) });
      if (res.ok) {
        setSent(true);
        setForm(f => ({ ...f, subject: '', message: '' }));
        if (user) { const r = await fetch(`/api/support?user_id=${user.id}`); setTickets(await r.json() || []); }
      }
    } catch (e) { console.error(e); } finally { setSubmitting(false); }
  };

  return (
    <div className="bg-royal pt-32 pb-20 min-h-screen px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><span>Concierge Support</span></div>
          <h1 className="font-display text-5xl sm:text-7xl text-cream mb-4">How May We <span className="font-italiana text-gradient-gold">Assist?</span></h1>
          <p className="text-cream-dim font-light">Answers, assistance, and attentive care — always at hand.</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <a href="#ticket" className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group"><Ticket size={24} className="text-gold mb-3" strokeWidth={1.5} /><h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Open a Ticket</h3><p className="text-xs text-cream-dim font-light">For detailed inquiries and written correspondence.</p></a>
          <button onClick={() => window.dispatchEvent(new Event('open-chat'))} className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group text-left"><MessageCircle size={24} className="text-gold mb-3" strokeWidth={1.5} /><h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Live Chat</h3><p className="text-xs text-cream-dim font-light">Instant conversation with our concierge team.</p></button>
          <a href="tel:+18885550192" className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group"><Phone size={24} className="text-gold mb-3" strokeWidth={1.5} /><h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Concierge Line</h3><p className="text-xs text-cream-dim font-light">+1 (888) 555-0192 · 24/7</p></a>
        </div>

        {/* FAQ */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6"><BookOpen size={20} className="text-gold" /><h2 className="font-display text-3xl text-cream">Frequently Asked</h2></div>
          <div className="space-y-2">
            {FAQS.map((faq, i) => (
              <div key={i} className="bg-card border-gold-soft border overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} className="w-full flex items-center justify-between p-5 text-left hover:bg-[rgba(201,169,97,0.04)] transition-colors">
                  <span className="font-display text-lg text-cream">{faq.q}</span>
                  <ChevronDown size={16} className={`text-gold transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="px-5 pb-5 text-sm text-cream-dim font-light leading-relaxed border-t border-gold-soft pt-4">{faq.a}</motion.div>}
              </div>
            ))}
          </div>
        </section>

        {/* Ticket Form */}
        <section id="ticket" className="mb-16">
          <div className="flex items-center gap-3 mb-6"><Ticket size={20} className="text-gold" /><h2 className="font-display text-3xl text-cream">Open a Ticket</h2></div>
          <div className="bg-card p-8 border-gold-soft border">
            {sent ? (
              <div className="text-center py-8">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center mx-auto mb-4"><Check size={26} className="text-[#0a0908]" strokeWidth={2.5} /></div>
                <h3 className="font-display text-2xl text-cream mb-2">Ticket Submitted</h3>
                <p className="text-cream-dim font-light mb-5">Our team will respond via email or live chat shortly.</p>
                <button onClick={() => setSent(false)} className="btn-secondary text-xs">Submit Another</button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div><label className="label-royal">Your Name</label><input type="text" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="input-royal" /></div>
                  <div><label className="label-royal">Email</label><input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="input-royal" /></div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div><label className="label-royal">Category</label><select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="input-royal"><option>General</option><option>Booking</option><option>Payment</option><option>Account</option><option>Discretion</option><option>Other</option></select></div>
                  <div><label className="label-royal">Priority</label><select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="input-royal"><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
                </div>
                <div><label className="label-royal">Subject</label><input type="text" required value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} className="input-royal" placeholder="A brief summary" /></div>
                <div><label className="label-royal">Message</label><textarea required rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} className="input-royal resize-none" placeholder="Tell us how we may assist..." /></div>
                <button type="submit" disabled={submitting} className="btn-primary"><Send size={14} /> {submitting ? 'Submitting…' : 'Submit Ticket'}</button>
              </form>
            )}
          </div>
        </section>

        {/* User Tickets */}
        {user && tickets.length > 0 && (
          <section>
            <h2 className="font-display text-2xl text-cream mb-5">Your Tickets</h2>
            <div className="space-y-3">
              {tickets.map(t => (
                <div key={t.id} className="bg-card p-5 border-gold-soft border">
                  <div className="flex items-start justify-between gap-3 mb-2"><h3 className="font-display text-lg text-cream">{t.subject}</h3><span className={`status-badge status-${t.status}`}>{t.status}</span></div>
                  <div className="text-xs text-cream-dim mb-2">{t.category} · {new Date(t.created_at).toLocaleDateString()}</div>
                  <p className="text-sm text-cream-dim font-light mb-2">{t.message}</p>
                  {t.admin_response && <div className="text-sm text-cream bg-[rgba(45,90,63,0.1)] border border-[rgba(45,90,63,0.3)] p-3 mt-2"><div className="text-gold text-[0.6rem] tracking-[0.2em] uppercase mb-1">Response</div>{t.admin_response}</div>}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
