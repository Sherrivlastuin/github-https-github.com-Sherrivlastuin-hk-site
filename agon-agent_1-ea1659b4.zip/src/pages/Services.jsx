import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, ArrowRight, Sparkles } from 'lucide-react';

function formatDuration(mins) {
  if (!mins) return '';
  if (mins < 60) return `${mins} minutes`;
  if (mins < 1440) { const h = Math.floor(mins / 60), m = mins % 60; return m > 0 ? `${h}h ${m}m` : `${h} hours`; }
  const d = Math.floor(mins / 1440); return `${d} ${d === 1 ? 'day' : 'days'}`;
}

export default function Services() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetch('/api/services').then(r => r.json()).then(data => { setServices(data || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const categories = ['all', ...new Set(services.map(s => s.category).filter(Boolean))];
  const filtered = filter === 'all' ? services : services.filter(s => s.category === filter);

  return (
    <div className="bg-royal pt-32 pb-20">
      {/* Header */}
      <section className="px-6 pb-12">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="ornament-line mb-8 justify-center"><span>The Collection</span></motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="font-display text-5xl sm:text-7xl text-cream mb-6">Our <span className="font-italiana text-gradient-gold">Services</span></motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="font-display italic text-xl text-cream-dim max-w-2xl mx-auto">A curated suite of experiences, each composed with intention.</motion.p>
        </div>
      </section>

      {/* Filters */}
      <section className="px-6 mb-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map(cat => (
              <button key={cat} onClick={() => setFilter(cat)}
                className={`px-5 py-2 text-xs tracking-[0.2em] uppercase transition-all border ${filter === cat ? 'border-gold bg-[rgba(201,169,97,0.1)] text-gold' : 'border-gold-soft text-cream-dim hover:border-gold hover:text-cream'}`}>
                {cat === 'all' ? 'All Experiences' : cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="px-6">
        <div className="max-w-7xl mx-auto">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => <div key={i} className="aspect-[4/5] bg-card shimmer" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((service, i) => (
                <motion.div key={service.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                  className="group relative bg-card border-gold-soft border hover:border-gold overflow-hidden transition-all duration-500">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    {service.image_url && <img src={service.image_url} alt={service.name} className="w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-700" />}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#14110f] via-[rgba(20,17,15,0.3)] to-transparent" />
                    {service.featured && (
                      <div className="absolute top-4 right-4 px-3 py-1 bg-[rgba(201,169,97,0.15)] border-gold border backdrop-blur-sm flex items-center gap-1">
                        <Sparkles size={11} className="text-gold" /><span className="text-[0.6rem] tracking-[0.2em] uppercase text-gold">Signature</span>
                      </div>
                    )}
                    <div className="absolute top-4 left-4 text-[0.65rem] tracking-[0.25em] uppercase text-gold">{service.category}</div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-2xl text-cream mb-2">{service.name}</h3>
                    <p className="text-sm text-cream-dim mb-5 font-light leading-relaxed line-clamp-3">{service.description}</p>
                    <div className="flex items-center gap-4 mb-5 text-xs text-cream-dim">
                      <span className="flex items-center gap-1.5"><Clock size={12} className="text-gold" /> {formatDuration(service.duration_minutes)}</span>
                    </div>
                    <div className="flex items-center justify-between pt-5 border-t border-gold-soft">
                      <div>
                        <div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-1">From</div>
                        <span className="font-display text-2xl text-cream">${(service.price_cents / 100).toLocaleString()}</span>
                      </div>
                      <Link to="/booking" state={{ serviceId: service.id }} className="btn-primary text-xs py-2.5 px-4">Reserve <ArrowRight size={12} /></Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Custom CTA */}
      <section className="py-20 px-6 mt-12">
        <div className="max-w-3xl mx-auto text-center bg-card p-10 border-gold-soft border">
          <h3 className="font-display text-3xl text-cream mb-3">Seeking something else?</h3>
          <p className="text-cream-dim mb-6 font-light">We compose entirely bespoke experiences for our distinguished members. Speak with our concierge to design something uniquely yours.</p>
          <Link to="/contact" className="btn-secondary">Speak to Concierge</Link>
        </div>
      </section>
    </div>
  );
}
