import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Crown, Mail, Lock, User, ArrowRight } from 'lucide-react';
import supabase from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { signInWithGoogle } from '../lib/googleAuth';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAdmin } = useAuth();
  const [mode, setMode] = useState('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const redirect = location.state?.from?.pathname || '/profile';

  useEffect(() => { if (user) navigate(isAdmin ? '/admin' : redirect, { replace: true }); }, [user]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
        if (error) throw error;
        if (data.user && !data.session) { setError('Please check your email to confirm your account, then sign in.'); setMode('signin'); return; }
        if (data.user) await fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: data.user.id, email, display_name: fullName || email.split('@')[0], role: 'customer' }) });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  };

  const google = () => signInWithGoogle('Charlotte Prestige Management');

  return (
    <div className="bg-royal min-h-screen flex items-center justify-center pt-24 pb-12 px-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-10">
          <Crown size={32} className="text-gold mx-auto mb-4" />
          <h1 className="font-display text-4xl text-cream mb-2">{mode === 'signin' ? 'Welcome Back' : 'Join the House'}</h1>
          <p className="text-cream-dim text-sm font-light">{mode === 'signin' ? 'Sign in to your private account.' : 'Create your discreet account.'}</p>
        </div>
        <div className="bg-card p-8 border-gold-soft border">
          <form onSubmit={submit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="label-royal">Your Name</label>
                <div className="relative">
                  <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gold" />
                  <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} placeholder="How we shall address you" className="input-royal pl-10" required />
                </div>
              </div>
            )}
            <div>
              <label className="label-royal">Email</label>
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gold" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="input-royal pl-10" required />
              </div>
            </div>
            <div>
              <label className="label-royal">Password</label>
              <div className="relative">
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gold" />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="input-royal pl-10" required minLength={6} />
              </div>
            </div>
            {error && <div className="text-xs text-[#a8424d] bg-[rgba(168,66,77,0.1)] border border-[rgba(168,66,77,0.3)] px-3 py-2">{error}</div>}
            <button type="submit" disabled={loading} className="btn-primary w-full">{loading ? 'Please wait…' : mode === 'signin' ? 'Sign In' : 'Create Account'} <ArrowRight size={14} /></button>
          </form>
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[rgba(201,169,97,0.15)]" />
            <span className="text-xs text-cream-dim tracking-[0.2em] uppercase">or</span>
            <div className="flex-1 h-px bg-[rgba(201,169,97,0.15)]" />
          </div>
          <button onClick={google} type="button" className="btn-secondary w-full text-xs">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </button>
          <div className="text-center mt-6 text-sm">
            <button type="button" onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(''); }} className="text-cream-dim hover:text-gold transition-colors">{mode === 'signin' ? "Don't have an account? Create one" : 'Already a member? Sign in'}</button>
          </div>
        </div>
        <div className="text-center mt-6 text-xs text-cream-dim"><Link to="/" className="hover:text-gold transition-colors">← Return Home</Link></div>
        <div className="mt-8 text-center text-xs text-cream-dim bg-[rgba(20,17,15,0.4)] border-gold-soft border p-4">
          <div className="ornament-line mb-2 justify-center"><span>Demo Access</span></div>
          <div className="font-mono text-[0.7rem]">
            <div>Customer: customer@royal.com / royal123</div>
            <div>Admin: admin@royal.com / royal123</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
