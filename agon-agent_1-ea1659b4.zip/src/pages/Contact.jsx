import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, MessageCircle, Send, Check } from 'lucide-react';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      if (res.ok) { setSent(true); setForm({ name: '', email: '', phone: '', subject: '', message: '' }); } else alert('Failed to send. Please try again.');
    } catch (e) { console.error(e); } finally { setSending(false); }
  };

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="bg-royal pt-32 pb-20 min-h-screen">
      {/* Header */}
      <section className="px-6 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20"><img src="/images/contact-bg.jpg" alt="" className="w-full h-full object-cover" /></div>
        <div className="absolute inset-0 bg-gradient-to-b from-[rgba(10,9,8,0.7)] to-[#0a0908]" />
        <div className="relative max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="ornament-line mb-8 justify-center"><span>Reach Us</span></motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="font-display text-5xl sm:text-7xl text-cream mb-4">Begin a <span className="font-italiana text-gradient-gold">Conversation</span></motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="font-display italic text-xl text-cream-dim max-w-2xl mx-auto">Our concierge stands ready to receive your inquiry, day or night.</motion.p>
        </div>
      </section>

      {/* Content */}
      <section className="px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Info */}
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-card p-7 border-gold-soft border">
              <h3 className="font-display text-2xl text-cream mb-5">Direct Channels</h3>
              <div className="space-y-5">
                <div className="flex items-start gap-4"><Mail size={18} className="text-gold flex-shrink-0 mt-0.5" /><div><div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-1">Email</div><a href="mailto:concierge@charlotteprestige.com" className="text-cream hover:text-gold transition-colors">concierge@charlotteprestige.com</a></div></div>
                <div className="flex items-start gap-4"><Phone size={18} className="text-gold flex-shrink-0 mt-0.5" /><div><div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-1">Concierge Line</div><div className="text-cream">+1 (888) 555-0192</div></div></div>
                <div className="flex items-start gap-4"><MapPin size={18} className="text-gold flex-shrink-0 mt-0.5" /><div><div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-1">Salons</div><div className="text-cream text-sm leading-relaxed">Manhattan · London · Dubai<br /><span className="text-cream-dim font-light">By appointment only</span></div></div></div>
                <div className="flex items-start gap-4"><Clock size={18} className="text-gold flex-shrink-0 mt-0.5" /><div><div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-1">Hours</div><div className="text-cream text-sm">24 hours · 7 days a week<br /><span className="text-cream-dim font-light">Concierge always available</span></div></div></div>
              </div>
            </div>
            <div className="bg-card p-7 border-gold-soft border">
              <div className="flex items-center gap-3 mb-3"><MessageCircle size={20} className="text-gold" /><h3 className="font-display text-xl text-cream">Live Chat</h3></div>
              <p className="text-sm text-cream-dim font-light leading-relaxed mb-3">For the swiftest reply, click the concierge button in the corner of your screen. Our team is online and ready to assist you discreetly.</p>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="bg-card p-8 border-gold-soft border">
              {sent ? (
                <div className="text-center py-10">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center mx-auto mb-4"><Check size={26} className="text-[#0a0908]" strokeWidth={2.5} /></div>
                  <h3 className="font-display text-2xl text-cream mb-2">Message Received</h3>
                  <p className="text-cream-dim font-light mb-5">Our concierge will be in touch shortly.</p>
                  <button onClick={() => setSent(false)} className="btn-secondary text-xs">Send Another</button>
                </div>
              ) : (
                <form onSubmit={submit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div><label className="label-royal">Your Name</label><input type="text" required value={form.name} onChange={e => update('name', e.target.value)} className="input-royal" placeholder="As you wish to be addressed" /></div>
                    <div><label className="label-royal">Email</label><input type="email" required value={form.email} onChange={e => update('email', e.target.value)} className="input-royal" placeholder="you@example.com" /></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div><label className="label-royal">Phone <span className="text-cream-dim normal-case tracking-normal">(optional)</span></label><input type="tel" value={form.phone} onChange={e => update('phone', e.target.value)} className="input-royal" placeholder="+1 (555) 000-0000" /></div>
                    <div><label className="label-royal">Subject</label>
                      <select value={form.subject} onChange={e => update('subject', e.target.value)} className="input-royal" required>
                        <option value="">Select a topic</option>
                        <option>General Inquiry</option><option>Private Companionship</option><option>Couples Experience</option><option>Weekend Retreat</option><option>Travel Companion</option><option>Event Hosting</option><option>Membership</option>
                      </select>
                    </div>
                  </div>
                  <div><label className="label-royal">Your Message</label><textarea required rows={6} value={form.message} onChange={e => update('message', e.target.value)} className="input-royal resize-none" placeholder="Share as much or as little as you wish. Every word is held in confidence." /></div>
                  <button type="submit" disabled={sending} className="btn-primary w-full md:w-auto"><Send size={14} /> {sending ? 'Sending…' : 'Send to Concierge'}</button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
