import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Crown, Shield, Heart, Sparkles, Lock, Star, Calendar, ArrowRight, MessageCircle } from 'lucide-react';

export default function Home() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/services').then(r => r.json()).then(data => {
      setServices((data || []).filter(s => s.featured));
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return (
    <div className="bg-royal">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/hero.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 hero-overlay" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0a0908]" />
        </div>
        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center pt-24">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="ornament-line mb-8 justify-center">
            <Crown size={14} /> <span>Est. Anno MMXXV</span> <Crown size={14} />
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.2 }} className="font-display text-5xl sm:text-7xl lg:text-8xl text-cream leading-[1.05] mb-6">
            The Art of<br /><span className="font-italiana text-gradient-gold">Refined Indulgence</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.5 }} className="font-display italic text-xl sm:text-2xl text-cream-dim max-w-2xl mx-auto mb-3">Where discretion meets desire.</motion.p>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.7 }} className="text-sm text-cream-dim max-w-xl mx-auto mb-10 leading-relaxed font-light">A bespoke concierge for those who seek the extraordinary. Every encounter curated. Every detail attended to. Every moment yours to command.</motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.9 }} className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/booking" className="btn-primary"><Calendar size={16} /> Reserve an Experience</Link>
            <Link to="/services" className="btn-secondary">Explore Services <ArrowRight size={16} /></Link>
          </motion.div>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 1.2 }} className="mt-16 flex flex-wrap justify-center gap-x-8 gap-y-4 text-cream-dim text-xs tracking-[0.2em] uppercase">
            <span className="flex items-center gap-2"><Lock size={12} className="text-gold" /> Absolute Discretion</span>
            <span className="flex items-center gap-2"><Shield size={12} className="text-gold" /> Verified Companions</span>
            <span className="flex items-center gap-2"><Star size={12} className="text-gold" /> Concierge Service</span>
          </motion.div>
        </div>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 1.5 }} className="absolute bottom-10 left-1/2 -translate-x-1/2">
          <div className="w-px h-16 bg-gradient-to-b from-transparent via-gold to-transparent" />
        </motion.div>
      </section>

      {/* Features */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="ornament-line mb-6 justify-center"><span>The Charlotte Prestige Difference</span></div>
            <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">A House of Distinction</h2>
            <p className="text-cream-dim max-w-xl mx-auto font-light">For over a decade we have refined the craft of companionship — where every detail is considered, every preference honored, every moment elevated.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[{ icon: Shield, title: 'Absolute Discretion', desc: 'Your privacy is our highest vow. Every interaction is conducted with the utmost confidentiality — from initial inquiry to final parting.' },
              { icon: Crown, title: 'Curated Excellence', desc: 'Our companions are hand-selected for their refinement, intelligence, and grace. Each one embodies the sophistication of the Charlotte Prestige standard.' },
              { icon: Heart, title: 'Bespoke Experiences', desc: 'No two encounters are alike. We tailor every detail to your desires — venue, ambiance, conversation, and company.' }
            ].map((feature, i) => (
              <motion.div key={feature.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }}
                className="bg-card p-8 hover:bg-card-hover transition-all duration-500 group">
                <feature.icon size={28} className="text-gold mb-5 group-hover:scale-110 transition-transform" strokeWidth={1.5} />
                <h3 className="font-display text-2xl text-cream mb-3">{feature.title}</h3>
                <p className="text-sm text-cream-dim leading-relaxed font-light">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-24 px-6 bg-gradient-to-b from-[rgba(20,17,15,0.6)] to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="ornament-line mb-6 justify-center"><span>Signature</span></div>
            <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">Bespoke Experiences</h2>
            <p className="text-cream-dim max-w-xl mx-auto font-light">Each offering is a chapter in our ongoing story of refined companionship.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {loading ? Array.from({ length: 4 }).map((_, i) => <div key={i} className="aspect-[3/4] bg-card shimmer" />) :
              services.map((service, i) => (
                <motion.div key={service.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="group relative aspect-[3/4] overflow-hidden bg-card border-gold-soft border hover:border-gold transition-all cursor-pointer">
                  {service.image_url && <img src={service.image_url} alt={service.name} className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-700" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0908] via-[rgba(10,9,8,0.4)] to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6">
                    <div className="text-gold text-[0.65rem] tracking-[0.25em] uppercase mb-2">{service.category}</div>
                    <h3 className="font-display text-2xl text-cream mb-2">{service.name}</h3>
                    <p className="text-xs text-cream-dim mb-4 font-light line-clamp-2">{service.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-cream font-display text-lg">${(service.price_cents / 100).toLocaleString()}</span>
                      <Link to="/booking" className="text-gold text-xs tracking-[0.2em] uppercase flex items-center gap-1 hover:gap-2 transition-all">Reserve <ArrowRight size={12} /></Link>
                    </div>
                  </div>
                </motion.div>
              ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/services" className="btn-secondary">View All Services <ArrowRight size={16} /></Link>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="ornament-line mb-6 justify-center"><span>The Process</span></div>
            <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">Effortless from Beginning to End</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[['Inquiry', 'A discreet introduction to our concierge, in person or by message.'],
              ['Curation', 'We match your desires to one of our refined companions.'],
              ['Arrangement', 'Every detail — venue, ambiance, timing — handled with care.'],
              ['Experience', 'An evening — or weekend — beyond expectation.']
            ].map(([title, desc], i) => (
              <div key={title} className="relative">
                <div className="text-gold font-italiana text-5xl mb-3 opacity-50">0{i + 1}</div>
                <h3 className="font-display text-xl text-cream mb-2">{title}</h3>
                <p className="text-sm text-cream-dim font-light leading-relaxed">{desc}</p>
                {i < 3 && <div className="hidden md:block absolute top-8 -right-3 w-6 h-px bg-gradient-to-r from-gold to-transparent" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card p-12 md:p-16 relative border-gold-soft border">
            <div className="ornament-line mb-6"><span>Words from Our Patrons</span></div>
            <Sparkles className="text-gold opacity-30 mb-4" size={40} />
            <blockquote className="font-display italic text-2xl md:text-3xl text-cream leading-relaxed mb-8">"Charlotte Prestige has redefined what I thought possible. The level of detail, the discretion, the sheer refinement — it is unlike anything else. Every encounter is masterfully composed."</blockquote>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center text-[#0a0908] font-italiana">A</div>
              <div>
                <div className="text-cream">A Distinguished Member</div>
                <div className="text-xs text-gold tracking-[0.2em] uppercase">Patron since 2021</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="ornament-line mb-6 justify-center"><span>Begin</span></div>
          <h2 className="font-display text-4xl sm:text-6xl text-cream mb-6">Your story awaits.</h2>
          <p className="text-cream-dim max-w-xl mx-auto mb-10 font-light leading-relaxed">A conversation is all it takes. Our concierge stands ready, day or night, to begin curating something unforgettable.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/booking" className="btn-primary"><Calendar size={16} /> Reserve an Experience</Link>
            <Link to="/contact" className="btn-secondary"><MessageCircle size={16} /> Speak to Concierge</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
