import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, Phone, Crown, Calendar, MessageCircle, ChevronRight, LogOut, Pen, Save, X, Ticket } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import supabase from '../lib/supabase';

export default function Profile() {
  const { user, profile, refreshProfile } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [edit, setEdit] = useState(false);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState('bookings');
  const [form, setForm] = useState({ display_name: '', phone: '', pronouns: '', bio: '', preferred_name: '', preferences: {} });

  useEffect(() => { if (user) loadData(); }, [user]);
  useEffect(() => {
    if (profile) setForm({ display_name: profile.display_name || '', phone: profile.phone || '', pronouns: profile.pronouns || '', bio: profile.bio || '', preferred_name: profile.preferred_name || '', preferences: profile.preferences || {} });
  }, [profile]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [b, t] = await Promise.all([fetch(`/api/appointments?user_id=${user.id}`).then(r => r.json()), fetch(`/api/support?user_id=${user.id}`).then(r => r.json())]);
      setBookings(b || []); setTickets(t || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const saveProfile = async () => {
    if (!profile) return;
    setSaving(true);
    try { await fetch('/api/profiles', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: profile.id, ...form }) }); await refreshProfile(); setEdit(false); }
    catch (e) { console.error(e); } finally { setSaving(false); }
  };

  const handleSignOut = async () => { await supabase.auth.signOut(); };

  if (loading) return <div className="bg-royal pt-32 pb-20 px-6 min-h-screen flex items-center justify-center"><div className="text-gold font-italiana tracking-[0.3em] text-2xl">LOADING</div></div>;

  return (
    <div className="bg-royal pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><span>My Account</span></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">Welcome, {profile?.display_name || 'Member'}</h1>
          <p className="text-cream-dim font-light">Your private corner of Charlotte Prestige.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-card p-7 border-gold-soft border sticky top-24">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-xl text-cream">Profile</h2>
                {edit ? (
                  <button onClick={() => setEdit(false)} className="text-cream-dim text-xs tracking-[0.15em] uppercase flex items-center gap-1"><X size={11} /> Cancel</button>
                ) : (
                  <button onClick={() => setEdit(true)} className="text-gold text-xs tracking-[0.15em] uppercase flex items-center gap-1 hover:gap-2 transition-all"><Pen size={11} /> Edit</button>
                )}
              </div>
              {edit ? (
                <div className="space-y-3">
                  <input type="text" placeholder="Display name" value={form.display_name} onChange={e => setForm({ ...form, display_name: e.target.value })} className="input-royal text-sm" />
                  <input type="text" placeholder="Preferred name" value={form.preferred_name} onChange={e => setForm({ ...form, preferred_name: e.target.value })} className="input-royal text-sm" />
                  <input type="tel" placeholder="Phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="input-royal text-sm" />
                  <input type="text" placeholder="Pronouns" value={form.pronouns} onChange={e => setForm({ ...form, pronouns: e.target.value })} className="input-royal text-sm" />
                  <textarea placeholder="Bio / notes" rows={3} value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} className="input-royal resize-none text-sm" />
                  <button onClick={saveProfile} disabled={saving} className="btn-primary w-full text-xs"><Save size={12} /> {saving ? 'Saving…' : 'Save Changes'}</button>
                </div>
              ) : (
                <div className="space-y-4 text-sm">
                  <div className="flex items-start gap-3"><User size={14} className="text-gold mt-0.5" /><div><div className="text-cream-dim text-[0.65rem] tracking-[0.2em] uppercase">Name</div><div className="text-cream">{profile?.display_name || '—'}</div></div></div>
                  <div className="flex items-start gap-3"><Mail size={14} className="text-gold mt-0.5" /><div><div className="text-cream-dim text-[0.65rem] tracking-[0.2em] uppercase">Email</div><div className="text-cream">{profile?.email || user?.email}</div></div></div>
                  <div className="flex items-start gap-3"><Phone size={14} className="text-gold mt-0.5" /><div><div className="text-cream-dim text-[0.65rem] tracking-[0.2em] uppercase">Phone</div><div className="text-cream">{profile?.phone || '—'}</div></div></div>
                  {profile?.pronouns && <div className="flex items-start gap-3"><Crown size={14} className="text-gold mt-0.5" /><div><div className="text-cream-dim text-[0.65rem] tracking-[0.2em] uppercase">Pronouns</div><div className="text-cream">{profile.pronouns}</div></div></div>}
                </div>
              )}
              <div className="border-t border-gold-soft mt-6 pt-5">
                <Link to="/booking" className="flex items-center justify-between text-sm text-cream hover:text-gold transition-colors group"><span className="flex items-center gap-2"><Calendar size={14} className="text-gold" /> New Reservation</span><ChevronRight size={14} /></Link>
                <Link to="/support" className="flex items-center justify-between text-sm text-cream hover:text-gold transition-colors mt-3 group"><span className="flex items-center gap-2"><MessageCircle size={14} className="text-gold" /> Open Support Ticket</span><ChevronRight size={14} /></Link>
                <button onClick={handleSignOut} className="flex items-center justify-between text-sm text-cream-dim hover:text-cream transition-colors mt-3 w-full"><span>Sign Out</span><ChevronRight size={14} /></button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="flex gap-1 mb-6 border-b border-gold-soft">
              <button onClick={() => setTab('bookings')} className={`px-5 py-3 text-xs tracking-[0.2em] uppercase transition-all border-b-2 -mb-px ${tab === 'bookings' ? 'border-gold text-gold' : 'border-transparent text-cream-dim hover:text-cream'}`}>Reservations ({bookings.length})</button>
              <button onClick={() => setTab('tickets')} className={`px-5 py-3 text-xs tracking-[0.2em] uppercase transition-all border-b-2 -mb-px ${tab === 'tickets' ? 'border-gold text-gold' : 'border-transparent text-cream-dim hover:text-cream'}`}>Support ({tickets.length})</button>
            </div>
            {tab === 'bookings' && (
              <div className="space-y-3">
                {bookings.length === 0 ? (
                  <div className="bg-card p-10 text-center border-gold-soft border"><Calendar size={32} className="text-gold mx-auto mb-3 opacity-50" /><p className="text-cream-dim mb-4">No reservations yet.</p><Link to="/booking" className="btn-primary text-xs">Book Your First Experience</Link></div>
                ) : bookings.map(b => (
                  <motion.div key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card p-5 border-gold-soft border hover:border-gold transition-all">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1"><span className="font-display text-lg text-cream">{b.services?.name}</span><span className={`status-badge status-${b.status}`}>{b.status}</span></div>
                        <div className="text-xs text-cream-dim space-x-4">
                          <span className="inline-flex items-center gap-1"><Calendar size={11} className="text-gold" /> {b.appointment_date}</span>
                          <span className="inline-flex items-center gap-1"><span className="text-gold">⏱</span> {b.appointment_time}</span>
                        </div>
                        {b.notes && <div className="mt-2 text-xs text-cream-dim italic border-l-2 border-gold-soft pl-3">"{b.notes}"</div>}
                      </div>
                      <div className="text-right">
                        <div className="text-[0.6rem] tracking-[0.2em] uppercase text-cream-dim">Res. No.</div>
                        <div className="font-display text-gold">#{String(b.id).padStart(4, '0')}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
            {tab === 'tickets' && (
              <div className="space-y-3">
                {tickets.length === 0 ? (
                  <div className="bg-card p-10 text-center border-gold-soft border"><Ticket size={32} className="text-gold mx-auto mb-3 opacity-50" /><p className="text-cream-dim mb-4">No support tickets yet.</p><Link to="/support" className="btn-primary text-xs">Open a Ticket</Link></div>
                ) : tickets.map(t => (
                  <div key={t.id} className="bg-card p-5 border-gold-soft border">
                    <div className="flex items-start justify-between gap-4 mb-2"><h3 className="font-display text-lg text-cream">{t.subject}</h3><span className={`status-badge status-${t.status}`}>{t.status}</span></div>
                    <div className="text-xs text-cream-dim mb-3">{t.category} · {new Date(t.created_at).toLocaleDateString()}</div>
                    <p className="text-sm text-cream-dim font-light mb-3">{t.message}</p>
                    {t.admin_response && <div className="text-sm text-cream bg-[rgba(45,90,63,0.1)] border border-[rgba(45,90,63,0.3)] p-3"><div className="text-gold text-[0.6rem] tracking-[0.2em] uppercase mb-1">Response</div>{t.admin_response}</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
