import { motion } from 'framer-motion';
import { Crown, Shield, Sparkles, Heart, Users, Globe } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-royal pt-32">
      {/* Header */}
      <section className="px-6 pb-20">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="ornament-line mb-8 justify-center"><span>The House</span></motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="font-display text-5xl sm:text-7xl text-cream mb-6">Our <span className="font-italiana text-gradient-gold">Story</span></motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="font-display italic text-xl text-cream-dim max-w-2xl mx-auto">A decade devoted to the craft of refined companionship.</motion.p>
        </div>
      </section>

      {/* Image Banner */}
      <section className="px-6 mb-20">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, scale: 0.96 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} className="relative aspect-[16/7] overflow-hidden border-gold-soft border">
            <img src="/images/about.jpg" alt="" className="w-full h-full object-cover opacity-60" />
            <div className="absolute inset-0 bg-gradient-to-r from-[rgba(10,9,8,0.7)] via-transparent to-[rgba(10,9,8,0.7)]" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="ornament-line"><Crown size={14} /> <span>Since MMXX</span> <Crown size={14} /></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Story */}
      <section className="px-6 py-20">
        <div className="max-w-3xl mx-auto space-y-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="font-display text-4xl text-cream mb-6">A House Built on Trust</h2>
            <p className="text-cream-dim leading-relaxed font-light mb-4">Charlotte Prestige was founded on a simple but uncompromising idea: that companionship, at its highest expression, is an art form. Not a transaction, but a craft — one that demands refinement, empathy, and an unwavering commitment to the person before us.</p>
            <p className="text-cream-dim leading-relaxed font-light">From a single salon in Manhattan, we have grown into a trusted house serving distinguished members across three continents. Yet our philosophy has never wavered: every encounter is bespoke, every detail considered, every confidence sacred.</p>
          </motion.div>
          <div className="divider-gold my-12" />
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="font-display text-4xl text-cream mb-6">Our Philosophy</h2>
            <p className="text-cream-dim leading-relaxed font-light mb-4">We believe that true luxury lies in the considered gesture, the unhurried moment, the conversation that lingers. Our companions are chosen for their depth as much as their beauty — well-traveled, well-read, fluent in the languages of art, wine, and wit.</p>
            <p className="text-cream-dim leading-relaxed font-light">Every arrangement begins with a conversation. We listen — to your preferences, your mood, the unspoken detail — and compose an experience that feels inevitable, as if it could not have unfolded any other way.</p>
          </motion.div>
        </div>
      </section>

      {/* Pillars */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="ornament-line mb-6 justify-center"><span>Our Vows</span></div>
            <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">The Pillars of Charlotte Prestige</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[{ icon: Shield, title: 'Discretion', text: 'Every conversation is held in strictest confidence. Our members\' identities are never disclosed, never recorded, never shared.' },
              { icon: Sparkles, title: 'Refinement', text: 'From the cut of a suit to the choice of vintage, every detail is considered. We attend to the things you would never think to ask for.' },
              { icon: Heart, title: 'Genuine Connection', text: 'Our companions are present, attentive, and authentically engaged. The art of conversation is the foundation of everything we offer.' },
              { icon: Crown, title: 'Excellence', text: 'Only the most exceptional individuals join the Charlotte Prestige family. Each companion is interviewed, vetted, and trained to our exacting standards.' },
              { icon: Users, title: 'Bespoke Service', text: 'No two members are the same, and no two experiences should be. Every encounter is composed uniquely for you.' },
              { icon: Globe, title: 'Worldwide Reach', text: 'From Manhattan to Mykonos, London to Dubai — wherever your travels take you, a Charlotte Prestige companion can be arranged.' }
            ].map((pillar, i) => (
              <motion.div key={pillar.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="bg-card p-7 hover:bg-card-hover transition-all duration-500">
                <pillar.icon size={26} className="text-gold mb-4" strokeWidth={1.5} />
                <h3 className="font-display text-xl text-cream mb-3">{pillar.title}</h3>
                <p className="text-sm text-cream-dim leading-relaxed font-light">{pillar.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 px-6 bg-gradient-to-b from-transparent via-[rgba(45,90,63,0.08)] to-transparent">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[['10+', 'Years of Service'], ['1,200+', 'Distinguished Members'], ['85+', 'Curated Companions'], ['3', 'Continents']].map(([num, label]) => (
              <motion.div key={label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <div className="font-italiana text-5xl text-gradient-gold mb-2">{num}</div>
                <div className="text-xs tracking-[0.25em] uppercase text-cream-dim">{label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
