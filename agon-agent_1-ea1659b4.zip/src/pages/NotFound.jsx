import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Crown } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="bg-royal min-h-screen flex items-center justify-center px-6 pt-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-md">
        <Crown size={48} className="text-gold mx-auto mb-6 opacity-40" />
        <div className="font-italiana text-8xl text-gradient-gold mb-4">404</div>
        <h1 className="font-display text-4xl text-cream mb-4">A Wrong Turn</h1>
        <p className="text-cream-dim font-light mb-8">The path you sought has wandered beyond our halls. Allow us to guide you back.</p>
        <Link to="/" className="btn-primary">Return to the House</Link>
      </motion.div>
    </div>
  );
}
