import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Crown, Calendar, MessageCircle, Mail, Ticket, RefreshCw, ArrowUpRight, Funnel, Send, Filter, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import supabase from '../lib/supabase';

export default function AdminDashboard() {
  const { user, profile } = useAuth();
  const [tab, setTab] = useState('overview');
  const [appointments, setAppointments] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const channels = [];
    ['messages', 'appointments', 'contact_inquiries', 'support_tickets', 'conversations'].forEach(table => {
      const ch = supabase.channel(`admin-${table}`).on('postgres_changes', { event: '*', schema: 'public', table }, () => loadData()).subscribe();
      channels.push(ch);
    });
    return () => channels.forEach(ch => supabase.removeChannel(ch));
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [a, c, i, t, m] = await Promise.all([
        fetch('/api/appointments').then(r => r.json()),
        fetch('/api/conversations').then(r => r.json()),
        fetch('/api/contact').then(r => r.json()),
        fetch('/api/support').then(r => r.json()),
        fetch('/api/messages').then(r => r.json()).catch(() => []),
      ]);
      setAppointments(a || []);
      setConversations(c || []);
      setInquiries(i || []);
      setTickets(t || []);
      setUnreadCount((m || []).filter(msg => !msg.is_read && msg.sender_type === 'visitor').length);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const stats = {
    pending: appointments.filter(a => a.status === 'pending').length,
    confirmed: appointments.filter(a => a.status === 'confirmed').length,
    openChats: conversations.filter(c => c.status === 'open').length,
    newInquiries: inquiries.filter(i => i.status === 'new').length,
    openTickets: tickets.filter(t => t.status === 'open').length,
    totalAppointments: appointments.length,
  };

  const TABS = [
    { id: 'overview', label: 'Overview', icon: Crown },
    { id: 'appointments', label: 'Appointments', icon: Calendar, count: appointments.length },
    { id: 'chats', label: 'Live Chats', icon: MessageCircle, count: unreadCount, badge: unreadCount > 0 },
    { id: 'inquiries', label: 'Inquiries', icon: Mail, count: inquiries.filter(i => i.status === 'new').length },
    { id: 'tickets', label: 'Support', icon: Ticket, count: tickets.filter(t => t.status === 'open').length },
  ];

  const updateAppointmentStatus = async (id, status) => {
    await fetch('/api/appointments', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
    loadData();
  };

  const respondToInquiry = async (id, response) => {
    await fetch('/api/contact', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, admin_response: response, status: 'resolved' }) });
    loadData();
  };

  const respondToTicket = async (id, response) => {
    await fetch('/api/support', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, admin_response: response, status: 'resolved' }) });
    loadData();
  };

  return (
    <div className="bg-royal pt-24 pb-12 px-4 sm:px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="ornament-line mb-3"><span>Charlotte Prestige Administration</span></div>
            <h1 className="font-display text-4xl text-cream">Concierge Dashboard</h1>
            <p className="text-cream-dim text-sm mt-1">Welcome back, <span className="text-gold">{profile?.display_name || user?.email}</span></p>
          </div>
          <button onClick={loadData} className="btn-secondary text-xs"><RefreshCw size={12} /> Refresh</button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 overflow-x-auto pb-2 border-b border-gold-soft">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`px-4 py-2.5 text-xs tracking-[0.15em] uppercase transition-all border-b-2 -mb-px flex items-center gap-2 whitespace-nowrap ${tab === t.id ? 'border-gold text-gold bg-[rgba(201,169,97,0.06)]' : 'border-transparent text-cream-dim hover:text-cream'}`}>
              <t.icon size={13} /> {t.label}
              {t.count > 0 && <span className={`px-1.5 py-0.5 text-[0.6rem] rounded-full ${t.badge ? 'bg-[#a8424d] text-white' : 'bg-[rgba(201,169,97,0.15)] text-gold'}`}>{t.count}</span>}
            </button>
          ))}
        </div>

        {loading && tab === 'overview' ? (
          <div className="text-center py-20 text-cream-dim">Loading...</div>
        ) : (
          <>
            {/* Overview */}
            {tab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {[{ label: 'Pending', val: stats.pending }, { label: 'Confirmed', val: stats.confirmed }, { label: 'Open Chats', val: stats.openChats }, { label: 'New Inquiries', val: stats.newInquiries }, { label: 'Open Tickets', val: stats.openTickets }].map(s => (
                    <div key={s.label} className="bg-card p-5 border-gold-soft border">
                      <div className="text-[0.65rem] tracking-[0.2em] uppercase text-cream-dim mb-2">{s.label}</div>
                      <div className="font-italiana text-4xl text-gradient-gold">{s.val}</div>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-card p-6 border-gold-soft border">
                    <div className="flex items-center justify-between mb-4"><h3 className="font-display text-lg text-cream">Upcoming Appointments</h3><button onClick={() => setTab('appointments')} className="text-xs text-gold tracking-[0.15em] uppercase flex items-center gap-1">View All <ArrowUpRight size={11} /></button></div>
                    <div className="space-y-2">
                      {appointments.filter(a => a.status === 'pending' || a.status === 'confirmed').slice(0, 5).map(a => (
                        <div key={a.id} className="flex items-center justify-between p-3 bg-[rgba(10,9,8,0.4)] border-gold-soft border">
                          <div><div className="text-cream text-sm">{a.services?.name}</div><div className="text-xs text-cream-dim">{a.customer_name} · {a.appointment_date} {a.appointment_time}</div></div>
                          <span className={`status-badge status-${a.status}`}>{a.status}</span>
                        </div>
                      ))}
                      {appointments.filter(a => a.status === 'pending' || a.status === 'confirmed').length === 0 && <div className="text-center text-cream-dim text-sm py-6">No upcoming appointments</div>}
                    </div>
                  </div>
                  <div className="bg-card p-6 border-gold-soft border">
                    <div className="flex items-center justify-between mb-4"><h3 className="font-display text-lg text-cream">Recent Conversations</h3><button onClick={() => setTab('chats')} className="text-xs text-gold tracking-[0.15em] uppercase flex items-center gap-1">View All <ArrowUpRight size={11} /></button></div>
                    <div className="space-y-2">
                      {conversations.slice(0, 5).map(c => (
                        <div key={c.id} className="flex items-center justify-between p-3 bg-[rgba(10,9,8,0.4)] border-gold-soft border">
                          <div className="min-w-0 flex-1"><div className="text-cream text-sm truncate">{c.visitor_name}</div><div className="text-xs text-cream-dim truncate">{c.last_message || 'No messages yet'}</div></div>
                          <span className={`status-badge status-${c.status} ml-2`}>{c.status}</span>
                        </div>
                      ))}
                      {conversations.length === 0 && <div className="text-center text-cream-dim text-sm py-6">No conversations yet</div>}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Appointments */}
            {tab === 'appointments' && (
              <AppointmentManager appointments={appointments} onUpdate={updateAppointmentStatus} />
            )}

            {/* Chats */}
            {tab === 'chats' && (
              <ChatManager conversations={conversations} onUpdate={loadData} />
            )}

            {/* Inquiries */}
            {tab === 'inquiries' && (
              <InquiryManager inquiries={inquiries} onRespond={respondToInquiry} />
            )}

            {/* Tickets */}
            {tab === 'tickets' && (
              <TicketManager tickets={tickets} onRespond={respondToTicket} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

function AppointmentManager({ appointments, onUpdate }) {
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? appointments : appointments.filter(a => a.status === filter);
  return (
    <div className="bg-card border-gold-soft border">
      <div className="p-5 border-b border-gold-soft flex items-center gap-3 overflow-x-auto">
        <Filter size={14} className="text-gold" />
        {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1 text-xs tracking-[0.15em] uppercase transition-all border ${filter === f ? 'border-gold bg-[rgba(201,169,97,0.1)] text-gold' : 'border-gold-soft text-cream-dim hover:text-cream'}`}>{f} {f !== 'all' && `(${appointments.filter(a => a.status === f).length})`}</button>
        ))}
      </div>
      <div className="divide-y divide-[rgba(201,169,97,0.08)]">
        {filtered.map(a => (
          <div key={a.id} className="p-5 hover:bg-[rgba(201,169,97,0.03)] transition-colors">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1"><span className="font-display text-lg text-cream">#{String(a.id).padStart(4, '0')} · {a.services?.name}</span><span className={`status-badge status-${a.status}`}>{a.status}</span></div>
                <div className="text-sm text-cream-dim mb-2"><span className="text-cream">{a.customer_name}</span> · {a.customer_email}{a.customer_phone && ` · ${a.customer_phone}`}</div>
                <div className="text-xs text-cream-dim flex gap-4"><span className="inline-flex items-center gap-1"><Calendar size={11} className="text-gold" /> {a.appointment_date}</span><span className="inline-flex items-center gap-1"><span className="text-gold">⏱</span> {a.appointment_time}</span></div>
                {a.notes && <div className="mt-2 text-xs text-cream-dim italic border-l-2 border-gold-soft pl-3">"{a.notes}"</div>}
              </div>
              <div className="flex gap-1">
                {a.status === 'pending' && <button onClick={() => onUpdate(a.id, 'confirmed')} className="px-3 py-1.5 text-xs bg-[rgba(45,90,63,0.3)] border border-[rgba(45,90,63,0.5)] text-cream hover:bg-[rgba(45,90,63,0.5)] transition-colors">Confirm</button>}
                {a.status !== 'completed' && a.status !== 'cancelled' && <button onClick={() => onUpdate(a.id, 'completed')} className="px-3 py-1.5 text-xs border-gold-soft border text-cream-dim hover:text-gold hover:border-gold transition-colors">Complete</button>}
                {a.status !== 'cancelled' && <button onClick={() => onUpdate(a.id, 'cancelled')} className="px-3 py-1.5 text-xs text-[#a8424d] hover:bg-[rgba(168,66,77,0.15)] border border-[rgba(168,66,77,0.3)] transition-colors">Cancel</button>}
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="p-12 text-center text-cream-dim">No appointments found.</div>}
      </div>
    </div>
  );
}

function ChatManager({ conversations, onUpdate }) {
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (selected) loadMessages(selected.id);
  }, [selected]);

  useEffect(() => {
    if (!selected) return;
    const ch = supabase.channel(`admin-chat-${selected.id}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${selected.id}` }, (payload) => {
      setMessages(prev => prev.find(m => m.id === payload.new.id) ? prev : [...prev, payload.new]);
    }).subscribe();
    return () => supabase.removeChannel(ch);
  }, [selected]);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages]);

  const loadMessages = async (convId) => {
    const data = await fetch(`/api/messages?conversation_id=${convId}`).then(r => r.json());
    setMessages(data || []);
    (data || []).filter(m => !m.is_read && m.sender_type === 'visitor').forEach(m => fetch('/api/messages', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: m.id, is_read: true }) }));
  };

  const sendMessage = async () => {
    if (!input.trim() || !selected) return;
    setSending(true);
    try {
      await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation_id: selected.id, sender_type: 'admin', sender_name: 'Charlotte Prestige Concierge', content: input.trim(), is_read: true }) });
      await fetch('/api/conversations', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: selected.id, last_message: input.trim(), last_message_at: new Date().toISOString() }) });
      setInput('');
      onUpdate();
    } finally { setSending(false); }
  };

  const closeChat = async (id) => { await fetch('/api/conversations', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status: 'closed' }) }); onUpdate(); setSelected(null); };

  const sorted = [...conversations].sort((a, b) => { const at = a.last_message_at ? new Date(a.last_message_at).getTime() : new Date(a.created_at).getTime(); const bt = b.last_message_at ? new Date(b.last_message_at).getTime() : new Date(b.created_at).getTime(); return bt - at; });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[600px]">
      <div className="bg-card border-gold-soft border overflow-hidden flex flex-col">
        <div className="p-4 border-b border-gold-soft"><h3 className="font-display text-lg text-cream">Conversations</h3></div>
        <div className="flex-1 overflow-y-auto">
          {sorted.length === 0 ? <div className="p-8 text-center text-cream-dim text-sm">No conversations yet</div> : sorted.map(c => (
            <button key={c.id} onClick={() => setSelected(c)} className={`w-full text-left p-4 border-b border-gold-soft transition-colors ${selected?.id === c.id ? 'bg-[rgba(201,169,97,0.08)]' : 'hover:bg-[rgba(201,169,97,0.04)]'}`}>
              <div className="flex items-start justify-between gap-2 mb-1"><span className="text-cream text-sm font-medium">{c.visitor_name}</span><span className={`status-badge status-${c.status}`}>{c.status}</span></div>
              <div className="text-xs text-cream-dim truncate">{c.last_message || 'New conversation'}</div>
              {c.last_message_at && <div className="text-[0.65rem] text-cream-dim mt-1">{new Date(c.last_message_at).toLocaleString()}</div>}
            </button>
          ))}
        </div>
      </div>
      <div className="lg:col-span-2 bg-card border-gold-soft border flex flex-col">
        {selected ? (
          <>
            <div className="p-4 border-b border-gold-soft flex items-center justify-between bg-gradient-to-r from-[rgba(45,90,63,0.15)] to-transparent">
              <div><h3 className="font-display text-lg text-cream">{selected.visitor_name}</h3>{selected.visitor_email && <div className="text-xs text-cream-dim">{selected.visitor_email}</div>}</div>
              {selected.status === 'open' && <button onClick={() => closeChat(selected.id)} className="text-xs text-cream-dim hover:text-cream tracking-[0.15em] uppercase">Close</button>}
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-3 bg-[rgba(10,9,8,0.3)]">
              {messages.map(m => (
                <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`flex ${m.sender_type === 'admin' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] px-4 py-2.5 text-sm leading-relaxed ${m.sender_type === 'admin' ? 'bg-gradient-to-br from-[rgba(201,169,97,0.9)] to-[rgba(168,136,74,0.9)] text-[#0a0908] rounded-l-lg rounded-tr-lg' : 'bg-[rgba(34,29,24,0.95)] text-cream border-gold-soft border rounded-r-lg rounded-tl-lg'}`}>
                    <div className="text-[0.6rem] tracking-[0.15em] uppercase opacity-60 mb-1">{m.sender_name}</div>{m.content}
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="p-4 border-t border-gold-soft flex gap-2">
              <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()} placeholder="Type your reply…" className="input-royal" />
              <button onClick={sendMessage} disabled={!input.trim() || sending} className="btn-primary px-4 flex-shrink-0"><Send size={14} /></button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-cream-dim"><div className="text-center"><MessageCircle size={40} className="text-gold mx-auto mb-3 opacity-40" /><p className="text-sm">Select a conversation to begin</p></div></div>
        )}
      </div>
    </div>
  );
}

function InquiryManager({ inquiries, onRespond }) {
  const [selected, setSelected] = useState(null);
  const [response, setResponse] = useState('');

  useEffect(() => { if (selected) setResponse(selected.admin_response || ''); }, [selected]);

  const respond = async () => {
    if (!selected || !response.trim()) return;
    await onRespond(selected.id, response);
    setResponse('');
    setSelected(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-1 bg-card border-gold-soft border max-h-[600px] overflow-y-auto">
        <div className="p-4 border-b border-gold-soft"><h3 className="font-display text-lg text-cream">Inquiries ({inquiries.length})</h3></div>
        {inquiries.map(i => (
          <button key={i.id} onClick={() => setSelected(i)} className={`w-full text-left p-4 border-b border-gold-soft transition-colors ${selected?.id === i.id ? 'bg-[rgba(201,169,97,0.08)]' : 'hover:bg-[rgba(201,169,97,0.04)]'}`}>
            <div className="flex items-start justify-between gap-2 mb-1"><span className="text-cream text-sm font-medium">{i.name}</span><span className={`status-badge status-${i.status}`}>{i.status}</span></div>
            <div className="text-xs text-gold mb-1">{i.subject}</div>
            <div className="text-xs text-cream-dim line-clamp-2">{i.message}</div>
          </button>
        ))}
        {inquiries.length === 0 && <div className="p-8 text-center text-cream-dim text-sm">No inquiries yet</div>}
      </div>
      <div className="lg:col-span-2 bg-card border-gold-soft border min-h-[400px]">
        {selected ? (
          <div className="p-6">
            <div className="flex items-start justify-between mb-5">
              <div><h3 className="font-display text-2xl text-cream">{selected.name}</h3><div className="text-sm text-cream-dim mt-1">{selected.email} {selected.phone && `· ${selected.phone}`}</div></div>
              <span className={`status-badge status-${selected.status}`}>{selected.status}</span>
            </div>
            <div className="bg-[rgba(10,9,8,0.4)] border-gold-soft border p-4 mb-5">
              <div className="text-gold text-[0.65rem] tracking-[0.2em] uppercase mb-2">{selected.subject}</div>
              <p className="text-cream text-sm leading-relaxed">{selected.message}</p>
              <div className="text-xs text-cream-dim mt-3">{new Date(selected.created_at).toLocaleString()}</div>
            </div>
            <label className="label-royal">Your Response</label>
            <textarea value={response} onChange={e => setResponse(e.target.value)} rows={6} className="input-royal resize-none" placeholder="Compose your reply…" />
            <div className="flex justify-end mt-4 gap-2">
              <button onClick={() => setSelected(null)} className="btn-ghost">Cancel</button>
              <button onClick={respond} disabled={!response.trim()} className="btn-primary text-xs"><Send size={12} /> Send Response & Mark Resolved</button>
            </div>
          </div>
        ) : <div className="flex items-center justify-center h-full text-cream-dim"><div className="text-center"><Mail size={40} className="text-gold mx-auto mb-3 opacity-40" /><p className="text-sm">Select an inquiry to view and respond</p></div></div>}
      </div>
    </div>
  );
}

function TicketManager({ tickets, onRespond }) {
  const [selected, setSelected] = useState(null);
  const [response, setResponse] = useState('');

  useEffect(() => { if (selected) setResponse(selected.admin_response || ''); }, [selected]);

  const respond = async () => {
    if (!selected || !response.trim()) return;
    await onRespond(selected.id, response);
    setResponse('');
    setSelected(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-1 bg-card border-gold-soft border max-h-[600px] overflow-y-auto">
        <div className="p-4 border-b border-gold-soft"><h3 className="font-display text-lg text-cream">Tickets ({tickets.length})</h3></div>
        {tickets.map(t => (
          <button key={t.id} onClick={() => setSelected(t)} className={`w-full text-left p-4 border-b border-gold-soft transition-colors ${selected?.id === t.id ? 'bg-[rgba(201,169,97,0.08)]' : 'hover:bg-[rgba(201,169,97,0.04)]'}`}>
            <div className="flex items-start justify-between gap-2 mb-1"><span className="text-cream text-sm font-medium">{t.subject}</span><span className={`status-badge status-${t.status}`}>{t.status}</span></div>
            <div className="text-xs text-cream-dim">{t.name} · {t.category} · {t.priority}</div>
            <div className="text-xs text-cream-dim mt-1 line-clamp-1">{t.message}</div>
          </button>
        ))}
        {tickets.length === 0 && <div className="p-8 text-center text-cream-dim text-sm">No tickets yet</div>}
      </div>
      <div className="lg:col-span-2 bg-card border-gold-soft border min-h-[400px]">
        {selected ? (
          <div className="p-6">
            <div className="flex items-start justify-between mb-5">
              <div><h3 className="font-display text-2xl text-cream">{selected.subject}</h3><div className="text-sm text-cream-dim mt-1">{selected.name} · {selected.email}</div></div>
              <span className={`status-badge status-${selected.status}`}>{selected.status}</span>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-[rgba(10,9,8,0.4)] border-gold-soft border p-3"><div className="text-[0.6rem] tracking-[0.2em] uppercase text-cream-dim">Category</div><div className="text-cream text-sm">{selected.category}</div></div>
              <div className="bg-[rgba(10,9,8,0.4)] border-gold-soft border p-3"><div className="text-[0.6rem] tracking-[0.2em] uppercase text-cream-dim">Priority</div><div className="text-cream text-sm capitalize">{selected.priority}</div></div>
              <div className="bg-[rgba(10,9,8,0.4)] border-gold-soft border p-3"><div className="text-[0.6rem] tracking-[0.2em] uppercase text-cream-dim">Submitted</div><div className="text-cream text-sm">{new Date(selected.created_at).toLocaleDateString()}</div></div>
            </div>
            <div className="bg-[rgba(10,9,8,0.4)] border-gold-soft border p-4 mb-5"><p className="text-cream text-sm leading-relaxed">{selected.message}</p></div>
            <label className="label-royal">Your Response</label>
            <textarea value={response} onChange={e => setResponse(e.target.value)} rows={5} className="input-royal resize-none" placeholder="Compose your reply…" />
            <div className="flex justify-end mt-4 gap-2">
              <button onClick={() => setSelected(null)} className="btn-ghost">Cancel</button>
              <button onClick={respond} disabled={!response.trim()} className="btn-primary text-xs"><Send size={12} /> Send Response & Resolve</button>
            </div>
          </div>
        ) : <div className="flex items-center justify-center h-full text-cream-dim"><div className="text-center"><Ticket size={40} className="text-gold mx-auto mb-3 opacity-40" /><p className="text-sm">Select a ticket to view and respond</p></div></div>}
      </div>
    </div>
  );
}
