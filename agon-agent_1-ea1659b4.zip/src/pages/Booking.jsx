import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Calendar, Clock, Check, Crown, ArrowRight, ArrowLeft, User, Mail, Phone, FileText } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const TIME_SLOTS = ['10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00'];

function fmtDur(m) { if (!m) return ''; if (m < 60) return `${m} min`; if (m < 1440) { const h = Math.floor(m/60), r = m%60; return r > 0 ? `${h}h ${r}m` : `${h}h`; } return `${Math.floor(m/1440)}d`; }

export default function Booking() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [step, setStep] = useState(1);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [form, setForm] = useState({ service_id: location.state?.serviceId || '', customer_name: '', customer_email: '', customer_phone: '', appointment_date: '', appointment_time: '', notes: '' });

  useEffect(() => {
    fetch('/api/services').then(r => r.json()).then(data => { setServices(data || []); setLoading(false); if (location.state?.serviceId) setStep(2); }).catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (profile) setForm(f => ({ ...f, customer_name: profile.display_name || f.customer_name, customer_email: profile.email || f.customer_email, customer_phone: profile.phone || f.customer_phone }));
    else if (user) setForm(f => ({ ...f, customer_email: user.email || f.customer_email, customer_name: user.user_metadata?.full_name || f.customer_name }));
  }, [profile, user]);

  const selectedService = services.find(s => s.id === Number(form.service_id));
  const dates = Array.from({ length: 30 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() + i + 1); return { value: d.toISOString().split('T')[0], label: d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) }; });
  const update = (key, val) => setForm(f => ({ ...f, [key]: val }));
  const next = () => { if (step === 1 && form.service_id) setStep(2); else if (step === 2 && form.appointment_date && form.appointment_time) setStep(3); else if (step === 3) submit(); };
  const back = () => setStep(s => Math.max(1, s - 1));

  const submit = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/appointments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, service_id: Number(form.service_id), user_id: user?.id || null, duration_minutes: selectedService?.duration_minutes || 60, status: 'pending' }) });
      const data = await res.json();
      if (res.ok) { setResult(data); setStep(4); } else alert('Booking failed: ' + (data.error || 'Unknown error'));
    } catch (e) { console.error(e); alert('Booking failed. Please try again.'); } finally { setSubmitting(false); }
  };

  if (loading) return <div className="bg-royal pt-32 pb-20 px-6 min-h-screen flex items-center justify-center"><div className="text-gold font-italiana tracking-[0.3em] text-2xl">LOADING</div></div>;

  return (
    <div className="bg-royal pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><span>Reservations</span></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">Book an Experience</h1>
          <p className="text-cream-dim font-light">A few moments to begin your story.</p>
        </div>

        {/* Steps Indicator */}
        <div className="flex items-center justify-center mb-10 gap-2">
          {[1, 2, 3].map(n => (
            <div key={n} className="flex items-center">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-medium border transition-all ${step >= n ? 'border-gold bg-[rgba(201,169,97,0.15)] text-gold' : 'border-gold-soft text-cream-dim'}`}>
                {step > n ? <Check size={14} /> : n}
              </div>
              {n < 3 && <div className={`w-12 h-px ${step > n ? 'bg-gold' : 'bg-[rgba(201,169,97,0.15)]'}`} />}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-card p-8 md:p-10 border-gold-soft border">
              <h2 className="font-display text-3xl text-cream mb-2">Choose Your Experience</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">Select the offering that speaks to your intention.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {services.map(s => (
                  <button key={s.id} onClick={() => update('service_id', s.id)} className={`text-left p-4 border transition-all ${Number(form.service_id) === s.id ? 'border-gold bg-[rgba(201,169,97,0.08)]' : 'border-gold-soft hover:border-gold hover:bg-[rgba(201,169,97,0.04)]'}`}>
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-display text-lg text-cream">{s.name}</h3>
                      {Number(form.service_id) === s.id && <Check size={16} className="text-gold flex-shrink-0 mt-1" />}
                    </div>
                    <p className="text-xs text-cream-dim mb-3 font-light line-clamp-2">{s.description}</p>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-cream-dim flex items-center gap-1"><Clock size={11} className="text-gold" /> {fmtDur(s.duration_minutes)}</span>
                      <span className="text-gold font-display text-base">${(s.price_cents / 100).toLocaleString()}</span>
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-card p-8 md:p-10 border-gold-soft border">
              <h2 className="font-display text-3xl text-cream mb-2">When Shall We Meet?</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">Select a date and time for your experience.</p>
              {selectedService && (
                <div className="bg-[rgba(45,90,63,0.1)] border-gold-soft border p-4 mb-6 flex items-center gap-3">
                  <Crown size={20} className="text-gold flex-shrink-0" />
                  <div>
                    <div className="text-cream font-display">{selectedService.name}</div>
                    <div className="text-xs text-cream-dim">{fmtDur(selectedService.duration_minutes)} · ${(selectedService.price_cents / 100).toLocaleString()}</div>
                  </div>
                </div>
              )}
              <div className="mb-6">
                <label className="label-royal flex items-center gap-2"><Calendar size={12} /> Date</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-64 overflow-y-auto p-1">
                  {dates.map(d => (
                    <button key={d.value} onClick={() => update('appointment_date', d.value)} className={`px-3 py-3 text-xs border transition-all ${form.appointment_date === d.value ? 'border-gold bg-[rgba(201,169,97,0.1)] text-gold' : 'border-gold-soft text-cream-dim hover:border-gold hover:text-cream'}`}>{d.label}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="label-royal flex items-center gap-2"><Clock size={12} /> Time</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
                  {TIME_SLOTS.map(t => (
                    <button key={t} onClick={() => update('appointment_time', t)} className={`px-3 py-3 text-sm border transition-all ${form.appointment_time === t ? 'border-gold bg-[rgba(201,169,97,0.1)] text-gold' : 'border-gold-soft text-cream-dim hover:border-gold hover:text-cream'}`}>{t}</button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-card p-8 md:p-10 border-gold-soft border">
              <h2 className="font-display text-3xl text-cream mb-2">Your Details</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">A few details so our concierge may reach you discreetly.</p>
              <div className="space-y-5">
                <div>
                  <label className="label-royal flex items-center gap-2"><User size={12} /> Full Name</label>
                  <input type="text" value={form.customer_name} onChange={e => update('customer_name', e.target.value)} placeholder="As you wish to be addressed" className="input-royal" required />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="label-royal flex items-center gap-2"><Mail size={12} /> Email</label>
                    <input type="email" value={form.customer_email} onChange={e => update('customer_email', e.target.value)} placeholder="you@example.com" className="input-royal" required />
                  </div>
                  <div>
                    <label className="label-royal flex items-center gap-2"><Phone size={12} /> Phone</label>
                    <input type="tel" value={form.customer_phone} onChange={e => update('customer_phone', e.target.value)} placeholder="+1 (555) 000-0000" className="input-royal" />
                  </div>
                </div>
                <div>
                  <label className="label-royal flex items-center gap-2"><FileText size={12} /> Special Requests <span className="text-cream-dim normal-case tracking-normal">(optional)</span></label>
                  <textarea value={form.notes} onChange={e => update('notes', e.target.value)} rows={4} placeholder="Preferences, location, ambiance, or anything else we should know…" className="input-royal resize-none" />
                </div>
              </div>
              <div className="mt-6 p-4 bg-[rgba(45,90,63,0.08)] border-gold-soft border">
                <h4 className="text-gold text-xs tracking-[0.2em] uppercase mb-2">Reservation Summary</h4>
                <div className="text-sm text-cream space-y-1">
                  <div><span className="text-cream-dim">Experience:</span> {selectedService?.name}</div>
                  <div><span className="text-cream-dim">When:</span> {form.appointment_date} at {form.appointment_time}</div>
                  <div><span className="text-cream-dim">Investment:</span> ${(selectedService?.price_cents / 100).toLocaleString()}</div>
                </div>
              </div>
            </motion.div>
          )}
          {step === 4 && result && (
            <motion.div key="s4" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-card p-10 md:p-14 border-gold border text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#c9a961] to-[#a8884a] flex items-center justify-center mx-auto mb-6"><Check size={32} className="text-[#0a0908]" strokeWidth={2.5} /></div>
              <h2 className="font-display text-4xl text-cream mb-3">Reservation Received</h2>
              <p className="text-cream-dim font-light mb-8 max-w-md mx-auto">Thank you. A member of our concierge team will be in touch shortly to confirm the details of your experience.</p>
              <div className="bg-[rgba(45,90,63,0.1)] border-gold-soft border p-6 text-left max-w-md mx-auto mb-8">
                <div className="text-xs tracking-[0.2em] uppercase text-gold mb-3">Confirmation #{result.id}</div>
                <div className="space-y-2 text-sm text-cream">
                  <div><span className="text-cream-dim">Experience:</span> {result.services?.name}</div>
                  <div><span className="text-cream-dim">Date:</span> {result.appointment_date}</div>
                  <div><span className="text-cream-dim">Time:</span> {result.appointment_time}</div>
                </div>
              </div>
              <div className="flex gap-3 justify-center">
                <Link to="/" className="btn-secondary text-xs">Return Home</Link>
                {user && <Link to="/profile" className="btn-primary text-xs">View My Bookings</Link>}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {step < 4 && (
          <div className="flex items-center justify-between mt-6">
            <button onClick={back} disabled={step === 1} className="btn-ghost flex items-center gap-2 disabled:opacity-30"><ArrowLeft size={14} /> Back</button>
            <button onClick={next} disabled={(step === 1 && !form.service_id) || (step === 2 && (!form.appointment_date || !form.appointment_time)) || (step === 3 && (!form.customer_name || !form.customer_email)) || submitting} className="btn-primary">
              {submitting ? 'Submitting…' : step === 3 ? 'Confirm Reservation' : 'Continue'} <ArrowRight size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
